import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pdfreport',
  templateUrl: './pdfreport.component.html',
  styleUrls: ['./pdfreport.component.css']
})
export class PdfreportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
