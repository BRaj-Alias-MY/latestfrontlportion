import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from '../../../app.service';
import { Pin } from '../../../../pinupdate';
@Component({
  selector: 'app-instructions',
  templateUrl: './instructions.component.html',
  styleUrls: ['./instructions.component.css']
})
export class InstructionsComponent implements OnInit {
  status = localStorage.getItem('status');
  pin = localStorage.getItem('pin');
  email = localStorage.getItem('email');
  pinclass: Pin;

  constructor(private router: Router, private service: AppService) {
    this.pinclass = new Pin();
  }

  ngOnInit() {
    console.log(localStorage.getItem('status'));
    this.updatePin();
  }

  testsetup() {
    //alert('test');
    this.router.navigate(['/examboard/testsetup']);
  }
  updatePin() {


    if (this.status == 'Available') {
      this.status = 'Verified';
      this.pinclass.pin = parseInt(this.pin);
      this.pinclass.email = this.email;
      this.pinclass.status = this.status;

      this.service.updatePin(this.pinclass).subscribe(resp => { console.log(resp); localStorage.setItem('status', 'Verified') }, err => console.log(err));

    }

  }


}
