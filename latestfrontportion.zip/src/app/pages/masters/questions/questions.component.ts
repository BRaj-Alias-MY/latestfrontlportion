import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { Validators } from '@angular/forms';
import {MastersService} from '../services/masters.service';
import Swal from 'sweetalert2/dist/sweetalert2.js';
import { ValidationService } from '../../../services/validation.service';
import {GridOptions} from "ag-grid-community";
import { ChildMessageRenderer } from '../../../childmessagerender.component';
import { NgxSpinnerService } from 'ngx-spinner';



@Component({
  selector: 'app-questions',
  templateUrl: './questions.component.html',
  styleUrls: ['./questions.component.css']
})
export class QuestionsComponent implements OnInit {
 
  up_val : any;
  index = '';
  rpt_btn_name = '';
  update;
  items;
  btn_update = 'Update';
  btn_add = 'Add';
  access ;
  IsForUpdate: boolean = false;    
  newItem: any = {};    
  updatedItem; 
  btn_name: string;  
  current_page : number;
  start_record : number;
  pages;
  total_records: number;
  grid_tab = []; 
  sh_add: boolean;
  togel_name: string;
  view_item= [];
  private gridOptions: GridOptions;
	private gridApi;
	private gridColumnApi;

	private columnDefs;
	private rowData;
	private context;
	private frameworkComponents;

  constructor(private fb: FormBuilder, private route: Router, private api : MastersService, private spinner: NgxSpinnerService,
    private loading: NgxSpinnerService) {
    this.gridOptions = <GridOptions>{
			paginationNumberFormatter: function(params) {
				return '[' + params.value.toLocaleString() + ']';
			}
		};
		this.columnDefs = [
      { headerName: 'Question', field: 'question' },
      { headerName: 'Domain', field: 'domain.domainName' },
      { headerName: 'SubDomain', field: 'sub_domain.subDomainName' },
     // { headerName: 'Exp Level', field: 'exp_level.experiance' },
      
      { headerName: 'Created By', field: 'user.role.role_name' },
			{
				headerName: 'Action',
				cellRenderer: 'childMessageRenderer',
				colId: 'params',
				value: 'id'
			}
		];
		this.frameworkComponents = {
			childMessageRenderer: ChildMessageRenderer
		};
		this.context = { componentParent: this };
   }
   domainval;
   explevel;
   subdomain;
   selectedDevice;

  ngOnInit() {
    this.api.get_domains().subscribe(res=> this.domainval = res.data);
    this.api.get_explevels().subscribe(res=> this.explevel = res.data);
    
   
    this.sh_add = false;
    this.togel_name = 'Add';
    this.btn_name = 'Save';
    this.view_item = [];
    this.current_page = 1;
    this.pages = [];
    this.start_record = 1;
    this.update = false;
    this.access = [];
    this.rpt_btn_name = this.btn_add;
    this.up_val = '';
    this.grid();
   
}
onChange($event) {
  this.api.get_subdomain(this.selectedDevice).subscribe(res=> this.subdomain = res.data);
 }

 
  onEditClick(id) {
		console.log(id);
	}

	onGridReady(params) {
		this.gridApi = params.api;
		this.gridColumnApi = params.columnApi;

		params.api.sizeColumnsToFit();
	}
  questionForm = this.fb.group({
    id:[],
    question: [''],
    answer: [''],
    expLevelId: [''],
    difficulty: [''],
    mandatory: [''],
    global: [''],
    keywords: [''],
    domainId:[''],
    subDomainId: [''],
    time:['']
 });

 add_togel() {
  this.sh_add = this.sh_add ? false : true;
  this.togel_name = this.togel_name == 'Add' ? 'Close' : 'Add';
  this.btn_name = 'Save';
  this.questionForm.patchValue({ question: '',answer: '',expLevelId: '',difficulty: '',mandatory: '',global: '',keywords: '',domainId: '',subDomainId: '',time: '', });
}

 methodFromParentEdit(cell, valls) {
  //Swal("Edit");
  console.log(valls.id);
  this.EditItem(valls.id);
}

get_item_data_with_id(item_id) {
  for (let i = 0; i < this.grid_tab.length; i++) {
    if (this.grid_tab[i].id == item_id) {
      return this.grid_tab[i];
    }
  }
}
methodFromParentView(cell, valls) {
  // Swal("View");
  console.log(valls);
  this.ViewItem(valls.id);
}

EditItem(item_id) {
  // console.log(item_id);
  this.sh_add = true;
  this.togel_name = 'Close';
  this.btn_name = 'Update';
  this.questionForm.patchValue(this.get_item_data_with_id(item_id));
  //console.log(this.domainForm);
}

ViewItem(item_id) {
  this.view_item.push(this.get_item_data_with_id(item_id));
  //console.log(this.view_item);
  this.sh_add = false;
  this.togel_name = 'Add';
}

back_view() {
  this.view_item = [];
}
 

onSubmit() {
  this.loading.show();
  // this.domainForm.value.domain = this.domain;
  if (this.questionForm.value.id>0) {
    //alert('hi');
    this.api.question_update(this.questionForm.value).subscribe((res) => {
      if (res.status) {
        this.questionForm.patchValue({ id: '', question: ''});
       //this.loading.hide();
        this.grid();
        this.sh_add=false;
         Swal.fire('Success..', 'Record insert/updated successfully.', 'success');
        // this.clear_fields();
      } else {
        //this.loading.hide();
        Swal.fire('Oops...', 'Something went wrong!', 'error');
      }
    });
  } else {
    console.log(this.questionForm.value);
    this.api.add_question(this.questionForm.value).subscribe((res) => {
      if (res.status) {
        this.questionForm.patchValue({ id: '', question: '' });
        this.grid();
        this.sh_add=false;
        Swal.fire('Success..', 'Record insert/updated successfully.', 'success');
      } else {
        //this.loading.hide();
        Swal.fire('Oops...', 'Something went wrong!', 'error');
      }
    });
  }
}
grid(){
  this.api.get_questions_data().subscribe((data) => {
    this.access = data.access;
			if (this.access && this.access.gridAccess) {
				this.grid_tab = data.data;
			}
			this.sh_add = false;
			this.togel_name = 'Add';
			this.btn_name = 'Save';
			//this.loading.hide();
			this.view_item = [];
  }); 

}

}
